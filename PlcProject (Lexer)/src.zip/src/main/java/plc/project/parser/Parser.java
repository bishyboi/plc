package plc.project.parser;

import com.google.common.base.Preconditions;
import plc.project.lexer.Token;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * This style of parser is called <em>recursive descent</em>. Each rule in our
 * grammar has dedicated function, and references to other rules correspond to
 * calling that function. Recursive rules are therefore supported by actual
 * recursive calls, while operator precedence is encoded via the grammar.
 *
 * <p>
 * The parser has a similar architecture to the lexer, just with
 * {@link Token}s instead of characters. As before, {@link TokenStream#peek} and
 * {@link TokenStream#match} help with traversing the token stream. Instead of
 * emitting tokens, you will instead need to extract the literal value via
 * {@link TokenStream#get} to be added to the relevant AST.
 */
public final class Parser {

    private final TokenStream tokens;

    public Parser(List<Token> tokens) {
        this.tokens = new TokenStream(tokens);
    }

    public Ast parse(String rule) throws ParseException {
        var ast = switch (rule) {
            case "source" -> parseSource();
            case "stmt" -> parseStmt();
            case "expr" -> parseExpr();
            default -> throw new AssertionError(rule);
        };
        if (tokens.has(0)) {
            throw new ParseException("Expected end of input.", tokens.getNext());
        }
        return ast;
    }

    private Ast.Source parseSource() throws ParseException {
        var statements = new ArrayList<Ast.Stmt>();
        while (tokens.has(0)) {
            statements.add(parseStmt());
        }
        return new Ast.Source(statements);
    }

    // pick statement kind by first token
    private Ast.Stmt parseStmt() throws ParseException {
        if (tokens.peek("LET")) {
            return parseLetStmt();
        } else if (tokens.peek("DEF")) {
            return parseDefStmt();
        } else if (tokens.peek("IF")) {
            return parseIfStmt();
        } else if (tokens.peek("FOR")) {
            return parseForStmt();
        } else if (tokens.peek("RETURN")) {
            return parseReturnStmt();
        } else {
            return parseExpressionOrAssignmentStmt();
        }
    }

    // let name [= expr] ;
    private Ast.Stmt parseLetStmt() throws ParseException {
        // this shouldn't occur, but being safe
        if (!tokens.match("LET")) {
            throw new ParseException("Expected 'LET'.", tokens.getNext());
        }
        if (!tokens.match(Token.Type.IDENTIFIER)) {
            throw new ParseException("Expected variable name.", tokens.getNext());
        }
        String name = tokens.get(-1).literal();

        // after the equals sign which must come after the variable,
        // we can just call the expression operator to take care of the rest
        Optional<Ast.Expr> value = Optional.empty();
        if (tokens.match("=")) {
            value = Optional.of(parseExpr());
        }

        // the line must end in a semi-colon
        if (!tokens.match(";")) {
            throw new ParseException("Expected ';'.", tokens.getNext());
        }

        return new Ast.Stmt.Let(name, value);
    }

    // def name ( params ) do body end
    private Ast.Stmt parseDefStmt() throws ParseException {
        if (!tokens.match("DEF")) {
            throw new ParseException("Expected 'DEF'.", tokens.getNext());
        }
        if (!tokens.match(Token.Type.IDENTIFIER)) {
            throw new ParseException("Expected function name.", tokens.getNext());
        }
        String name = tokens.get(-1).literal();
        if (!tokens.match("(")) {
            throw new ParseException("Expected '('.", tokens.getNext());
        }

        List<String> parameters = new ArrayList<>();
        if (!tokens.peek(")")) {
            do {
                if (!tokens.match(Token.Type.IDENTIFIER)) {
                    throw new ParseException("Expected parameter name.", tokens.getNext());
                }
                parameters.add(tokens.get(-1).literal());
            } while (tokens.match(","));
        }
        if (!tokens.match(")")) {
            throw new ParseException("Expected ')'.", tokens.getNext());
        }
        if (!tokens.match("DO")) {
            throw new ParseException("Expected 'DO'.", tokens.getNext());
        }
        List<Ast.Stmt> body = new ArrayList<>();
        while (!tokens.peek("END")) {
            body.add(parseStmt());
        }

        if (!tokens.match("END")) {
            throw new ParseException("Expected 'END'.", tokens.getNext());
        }

        return new Ast.Stmt.Def(name, parameters, body);
    }

    // if expr do then [else else] end
    private Ast.Stmt parseIfStmt() throws ParseException {
        if (!tokens.match("IF")) {
            throw new ParseException("Expected 'IF'.", tokens.getNext());
        }

        Ast.Expr condition = parseExpr();

        if (!tokens.match("DO")) {
            throw new ParseException("Expected 'DO'.", tokens.getNext());
        }
        List<Ast.Stmt> thenStmts = new ArrayList<>();
        while (!tokens.peek("END") && !tokens.peek("ELSE")) {
            thenStmts.add(parseStmt());
        }

        List<Ast.Stmt> elseStmts = new ArrayList<>();
        if (tokens.match("ELSE")) {
            while (!tokens.peek("END")) {
                elseStmts.add(parseStmt());
            }
        }
        // single end closes if or else
        if (!tokens.match("END")) {
            throw new ParseException("Expected 'END'.", tokens.getNext());
        }

        return new Ast.Stmt.If(condition, thenStmts, elseStmts);
    }

    // for name in expr do body end
    private Ast.Stmt parseForStmt() throws ParseException {
        if (!tokens.match("FOR")) {
            throw new ParseException("Expected 'FOR'.", tokens.getNext());
        }
        if (!tokens.match(Token.Type.IDENTIFIER)) {
            throw new ParseException("Expected loop variable name.", tokens.getNext());
        }
        String name = tokens.get(-1).literal();

        if (!tokens.match("IN")) {
            throw new ParseException("Expected 'IN'.", tokens.getNext());
        }

        Ast.Expr iterable = parseExpr();

        if (!tokens.match("DO")) {
            throw new ParseException("Expected 'DO'.", tokens.getNext());
        }

        List<Ast.Stmt> body = new ArrayList<>();
        while (!tokens.peek("END")) {
            body.add(parseStmt());
        }

        if (!tokens.match("END")) {
            throw new ParseException("Expected 'END'.", tokens.getNext());
        }

        return new Ast.Stmt.For(name, iterable, body);
    }

    // return [expr] ; or return if expr ;
    private Ast.Stmt parseReturnStmt() throws ParseException {
        if (!tokens.match("RETURN")) {
            throw new ParseException("Expected 'RETURN'.", tokens.getNext());
        }
        // return if cond ; -> if cond do return ; end
        if (tokens.match("IF")) {
            Ast.Expr condition = parseExpr();
            if (!tokens.match(";")) {
                throw new ParseException("Expected ';'.", tokens.getNext());
            }
            return new Ast.Stmt.If(condition, List.of(new Ast.Stmt.Return(Optional.empty())), List.of());
        }

        Optional<Ast.Expr> value = Optional.empty();
        if (!tokens.peek(";")) {
            value = Optional.of(parseExpr());
        }

        if (!tokens.match(";")) {
            throw new ParseException("Expected ';'.", tokens.getNext());
        }

        return new Ast.Stmt.Return(value);
    }

    // expr ; or left = value ;
    private Ast.Stmt parseExpressionOrAssignmentStmt() throws ParseException {
        Ast.Expr left = parseExpr();
        if (tokens.match("=")) {
            Ast.Expr value = parseExpr();
            if (!tokens.match(";")) {
                throw new ParseException("Expected ';'.", tokens.getNext());
            }
            return new Ast.Stmt.Assignment(left, value);
        }
        if (!tokens.match(";")) {
            throw new ParseException("Expected ';'.", tokens.getNext());
        }

        return new Ast.Stmt.Expression(left);
    }

    // entry for expressions (starts at logical, delegates down)
    private Ast.Expr parseExpr() throws ParseException {
        return parseLogicalExpr();
    }

    // logical level (placeholder, goes to comparison)
    private Ast.Expr parseLogicalExpr() throws ParseException {
        return parseComparisonExpr();
    }

    // comparison level (placeholder, goes to additive)
    private Ast.Expr parseComparisonExpr() throws ParseException {
        return parseAdditiveExpr();
    }

    // + and - (left-assoc, lower precedence than * /)
    private Ast.Expr parseAdditiveExpr() throws ParseException {
        Ast.Expr left = parseMultiplicativeExpr();
        while (true) {
            if (tokens.match("+")) {
                left = new Ast.Expr.Binary("+", left, parseMultiplicativeExpr());
            } else if (tokens.match("-")) {
                left = new Ast.Expr.Binary("-", left, parseMultiplicativeExpr());
            } else {
                break;
            }
        }
        return left;
    }

    // * and / (left-assoc, higher precedence than + -)
    private Ast.Expr parseMultiplicativeExpr() throws ParseException {
        Ast.Expr left = parseSecondaryExpr();
        // chain * / left to right
        while (true) {
            if (tokens.match("*")) {
                left = new Ast.Expr.Binary("*", left, parseSecondaryExpr());
            } else if (tokens.match("/")) {
                left = new Ast.Expr.Binary("/", left, parseSecondaryExpr());
            } else {
                break;
            }
        }
        return left;
    }

    // primary then . name or . name ( args )
    private Ast.Expr parseSecondaryExpr() throws ParseException {
        Ast.Expr left = parsePrimaryExpr();
        while (tokens.peek(".")) {
            left = parsePropertyOrMethod(left);
        }
        return left;
    }

    // . name or . name ( args )
    private Ast.Expr parsePropertyOrMethod(Ast.Expr receiver) throws ParseException {
        if (!tokens.match(".")) {
            throw new ParseException("Expected '.'.", tokens.getNext());
        }
        if (!tokens.match(Token.Type.IDENTIFIER)) {
            throw new ParseException("Expected property or method name.", tokens.getNext());
        }
        String name = tokens.get(-1).literal();
        if (tokens.match("(")) {
            List<Ast.Expr> arguments = new ArrayList<>();
            if (!tokens.peek(")")) {
                do {
                    arguments.add(parseExpr());
                } while (tokens.match(","));
            }
            if (!tokens.match(")")) {
                throw new ParseException("Expected ')'.", tokens.getNext());
            }
            return new Ast.Expr.Method(receiver, name, arguments);
        }
        return new Ast.Expr.Property(receiver, name);
    }

    // literal, group, object, or variable/function (try in order)
    private Ast.Expr parsePrimaryExpr() throws ParseException {
        if (tokens.peek("NIL") || tokens.peek("TRUE") || tokens.peek("FALSE") ||
                tokens.peek(Token.Type.INTEGER) || tokens.peek(Token.Type.DECIMAL) ||
                tokens.peek(Token.Type.CHARACTER) || tokens.peek(Token.Type.STRING)) {
            return parseLiteralExprValue();
        }
        if (tokens.peek("(")) {
            return parseGroupExpr();
        }
        if (tokens.peek("OBJECT")) {
            return parseObjectExpr();
        }
        return parseVariableOrFunctionExpr();
    }

    // nil, true/false, integer, decimal, char, string
    private Ast.Expr parseLiteralExprValue() throws ParseException {
        if (tokens.match("NIL")) {
            return new Ast.Expr.Literal(null);
        }
        if (tokens.match("TRUE")) {
            return new Ast.Expr.Literal(true);
        }
        if (tokens.match("FALSE")) {
            return new Ast.Expr.Literal(false);
        }
        if (tokens.match(Token.Type.INTEGER)) {
            return new Ast.Expr.Literal(new BigInteger(tokens.get(-1).literal()));
        }
        if (tokens.match(Token.Type.DECIMAL)) {
            return new Ast.Expr.Literal(new BigDecimal(tokens.get(-1).literal()));
        }
        if (tokens.match(Token.Type.CHARACTER)) {
            String lit = tokens.get(-1).literal();
            char c = parseCharacterLiteral(lit);
            return new Ast.Expr.Literal(c);
        }
        if (tokens.match(Token.Type.STRING)) {
            String lit = tokens.get(-1).literal();
            String s = parseStringLiteral(lit);
            return new Ast.Expr.Literal(s);
        }
        throw new ParseException("Expected literal.", tokens.getNext());
    }

    // strip quotes, handle \n \t \' \\ etc
    private static char parseCharacterLiteral(String lit) {
        if (lit.length() >= 2 && lit.charAt(0) == '\'' && lit.charAt(lit.length() - 1) == '\'') {
            String inner = lit.substring(1, lit.length() - 1);
            if (inner.length() == 1)
                return inner.charAt(0);
            if (inner.length() == 2 && inner.charAt(0) == '\\') {
                return switch (inner.charAt(1)) {
                    case 'n' -> '\n';
                    case 't' -> '\t';
                    case 'r' -> '\r';
                    case '\'' -> '\'';
                    case '\\' -> '\\';
                    default -> inner.charAt(1);
                };
            }
        }
        return lit.length() > 0 ? lit.charAt(0) : '\0';
    }

    // unescape "..." with \\n etc
    private static String parseStringLiteral(String lit) {
        if (lit.length() >= 2 && lit.charAt(0) == '"' && lit.charAt(lit.length() - 1) == '"') {
            StringBuilder sb = new StringBuilder();
            for (int i = 1; i < lit.length() - 1; i++) {
                char c = lit.charAt(i);
                if (c == '\\' && i + 1 < lit.length() - 1) {
                    c = switch (lit.charAt(++i)) {
                        case 'n' -> '\n';
                        case 't' -> '\t';
                        case 'r' -> '\r';
                        case '"' -> '"';
                        case '\\' -> '\\';
                        default -> lit.charAt(i);
                    };
                }
                sb.append(c);
            }
            return sb.toString();
        }
        return lit;
    }

    // parenthesized expression ( expr )
    private Ast.Expr parseGroupExpr() throws ParseException {
        if (!tokens.match("(")) {
            throw new ParseException("Expected '('.", tokens.getNext());
        }
        if (tokens.peek(")")) {
            throw new ParseException("Expected expression.", tokens.getNext());
        }
        Ast.Expr expr = parseExpr();
        if (!tokens.match(")")) {
            throw new ParseException("Expected ')'.", tokens.getNext());
        }
        return new Ast.Expr.Group(expr);
    }

    // object do let/def ... end (fields and methods)
    private Ast.Expr parseObjectExpr() throws ParseException {
        if (!tokens.match("OBJECT")) {
            throw new ParseException("Expected 'OBJECT'.", tokens.getNext());
        }
        if (!tokens.match("DO")) {
            throw new ParseException("Expected 'DO'.", tokens.getNext());
        }
        List<Ast.Stmt.Let> fields = new ArrayList<>();
        List<Ast.Stmt.Def> methods = new ArrayList<>();
        while (!tokens.peek("END")) {
            if (tokens.peek("LET")) {
                // field
                Ast.Stmt let = parseLetStmt();
                if (let instanceof Ast.Stmt.Let letStmt) {
                    fields.add(letStmt);
                }
            } else if (tokens.peek("DEF")) {
                // method
                methods.add((Ast.Stmt.Def) parseDefStmt());
            } else {
                throw new ParseException("Expected field or method in object.", tokens.getNext());
            }
        }
        if (!tokens.match("END")) {
            throw new ParseException("Expected 'END'.", tokens.getNext());
        }
        return new Ast.Expr.ObjectExpr(Optional.empty(), fields, methods);
    }

    // identifier -> variable ; identifier ( args ) -> function call
    private Ast.Expr parseVariableOrFunctionExpr() throws ParseException {
        if (!tokens.match(Token.Type.IDENTIFIER)) {
            throw new ParseException("Expected variable or function.", tokens.getNext());
        }
        String name = tokens.get(-1).literal();
        if (tokens.match("(")) {
            List<Ast.Expr> arguments = new ArrayList<>();
            if (!tokens.peek(")")) {
                do {
                    arguments.add(parseExpr());
                } while (tokens.match(","));
            }
            if (!tokens.match(")")) {
                throw new ParseException("Expected ')'.", tokens.getNext());
            }
            return new Ast.Expr.Function(name, arguments);
        }
        // no ( so variable
        return new Ast.Expr.Variable(name);
    }

    private static final class TokenStream {

        private final List<Token> tokens;
        private int index = 0;

        private TokenStream(List<Token> tokens) {
            this.tokens = tokens;
        }

        /**
         * Returns true if there is a token at (index + offset).
         */
        public boolean has(int offset) {
            return index + offset < tokens.size();
        }

        /**
         * Returns the token at (index + offset).
         */
        public Token get(int offset) {
            Preconditions.checkState(has(offset));
            return tokens.get(index + offset);
        }

        /**
         * Returns the next token, if present.
         */
        public Optional<Token> getNext() {
            return index < tokens.size() ? Optional.of(tokens.get(index)) : Optional.empty();
        }

        /**
         * Returns true if the next characters match their corresponding
         * pattern. Each pattern is either a {@link Token.Type}, matching tokens
         * of that type, or a {@link String}, matching tokens with that literal.
         * In effect, {@code new Token(Token.Type.IDENTIFIER, "literal")} is
         * matched by both {@code peek(Token.Type.IDENTIFIER)} and
         * {@code peek("literal")}.
         */
        public boolean peek(Object... patterns) {
            if (!has(patterns.length - 1)) {
                return false;
            }
            for (int offset = 0; offset < patterns.length; offset++) {
                var token = tokens.get(index + offset);
                var pattern = patterns[offset];
                Preconditions.checkState(pattern instanceof Token.Type || pattern instanceof String, pattern);
                if (!token.type().equals(pattern) && !token.literal().equals(pattern)) {
                    return false;
                }
            }
            return true;
        }

        /**
         * Equivalent to peek, but also advances the token stream.
         */
        public boolean match(Object... patterns) {
            var peek = peek(patterns);
            if (peek) {
                index += patterns.length;
            }
            return peek;
        }

    }

}
